from django.apps import AppConfig


class AdminroleConfig(AppConfig):
    name = 'adminrole'
